/**
 * @file MLX90640_I2C_Driver.c
 * @brief MLX90640 I2C驱动适配层（适配ESP32 I2C接口）
 */

#include "MLX90640_I2C_Driver.h"
#include "driver/i2c.h"
#include "esp_log.h"

static const char *TAG = "MLX90640_I2C";
static i2c_port_t s_i2c_port = I2C_NUM_0;

void MLX90640_I2CInit(void) {
    // I2C已经在main.c中初始化
    ESP_LOGD(TAG, "I2C Init (already done in main)");
}

int MLX90640_I2CGeneralReset(void) {
    // 发送通用复位命令（可选）
    return 0;
}

int MLX90640_I2CRead(uint8_t slaveAddr, uint16_t startAddress, uint16_t nMemAddressRead, uint16_t *data) {
    esp_err_t ret;
    uint8_t cmd[2];
    uint8_t *pData = (uint8_t *)data;
    
    // MLX90640使用16位寄存器地址（大端）
    cmd[0] = (startAddress >> 8) & 0xFF;
    cmd[1] = startAddress & 0xFF;
    
    // 写寄存器地址
    i2c_cmd_handle_t cmd_handle = i2c_cmd_link_create();
    i2c_master_start(cmd_handle);
    i2c_master_write_byte(cmd_handle, (slaveAddr << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write(cmd_handle, cmd, 2, true);
    i2c_master_stop(cmd_handle);
    ret = i2c_master_cmd_begin(s_i2c_port, cmd_handle, 1000 / portTICK_PERIOD_MS);
    i2c_cmd_link_delete(cmd_handle);
    
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "I2C write address failed: %s", esp_err_to_name(ret));
        return -1;
    }
    
    // 读数据（每个数据2字节，大端）
    cmd_handle = i2c_cmd_link_create();
    i2c_master_start(cmd_handle);
    i2c_master_write_byte(cmd_handle, (slaveAddr << 1) | I2C_MASTER_READ, true);
    
    for (int i = 0; i < nMemAddressRead; i++) {
        if (i < nMemAddressRead - 1) {
            i2c_master_read(cmd_handle, &pData[i * 2], 2, I2C_MASTER_ACK);
        } else {
            i2c_master_read(cmd_handle, &pData[i * 2], 2, I2C_MASTER_NACK);
        }
        // 转换为小端（ESP32 Native）
        uint8_t tmp = pData[i * 2];
        pData[i * 2] = pData[i * 2 + 1];
        pData[i * 2 + 1] = tmp;
    }
    
    i2c_master_stop(cmd_handle);
    ret = i2c_master_cmd_begin(s_i2c_port, cmd_handle, 1000 / portTICK_PERIOD_MS);
    i2c_cmd_link_delete(cmd_handle);
    
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "I2C read data failed: %s", esp_err_to_name(ret));
        return -1;
    }
    
    return 0;
}

int MLX90640_I2CWrite(uint8_t slaveAddr, uint16_t writeAddress, uint16_t data) {
    esp_err_t ret;
    uint8_t cmd[4];
    
    // MLX90640写操作：地址（2字节）+ 数据（2字节，大端）
    cmd[0] = (writeAddress >> 8) & 0xFF;
    cmd[1] = writeAddress & 0xFF;
    cmd[2] = (data >> 8) & 0xFF;  // 高字节在前
    cmd[3] = data & 0xFF;        // 低字节在后
    
    i2c_cmd_handle_t cmd_handle = i2c_cmd_link_create();
    i2c_master_start(cmd_handle);
    i2c_master_write_byte(cmd_handle, (slaveAddr << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write(cmd_handle, cmd, 4, true);
    i2c_master_stop(cmd_handle);
    ret = i2c_master_cmd_begin(s_i2c_port, cmd_handle, 1000 / portTICK_PERIOD_MS);
    i2c_cmd_link_delete(cmd_handle);
    
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "I2C write failed: %s", esp_err_to_name(ret));
        return -1;
    }
    
    return 0;
}

void MLX90640_I2CFreqSet(int freq) {
    // 频率已经在i2c_init中设置
    ESP_LOGD(TAG, "Freq set to %d (ignored, set in i2c_init)", freq);
}
